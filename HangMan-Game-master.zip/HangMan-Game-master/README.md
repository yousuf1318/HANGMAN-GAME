## Python-Hangman
In this project, I have made hangman game using Python. Hangman is a paper and pencil guessing game. Player thinks of a word, phrase or sentence and tries to guess it by suggesting letters or numbers, within a certain number of guesses. Player has the length of the word that have to guess, with some lifelines.

## Requirements
If you are on Linux-based system, run the following command on your terminal to install python3.

    sudo apt-get update && sudo apt-get install python3

If you are on the Windows, please download it from https://www.python.org/downloads/

## How to run the code?
After finishing installation process, you can run like,

    python3 hangman.py
